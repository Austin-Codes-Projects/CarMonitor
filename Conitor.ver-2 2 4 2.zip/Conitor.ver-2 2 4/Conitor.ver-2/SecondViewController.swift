//
//  SecondViewController.swift
//  Conitor.ver-2
//
//  Created by Sunesh, Austin on 2023-05-30.
//

import UIKit

class SecondViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationItem.hidesBackButton = true
    }


}
